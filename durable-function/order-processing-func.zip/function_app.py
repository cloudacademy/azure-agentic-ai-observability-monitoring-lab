import azure.functions as func
import azure.durable_functions as df
import logging
from time import sleep 
from models import *

myApp = df.DFApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@myApp.route(route="orchestrators/process_orchestrator")
@myApp.durable_client_input(client_name="client")
async def http_start(req: func.HttpRequest, client):    
    try:
        body = req.get_json()
    except ValueError:
        body = {}

    order_name = req.params.get("orderName", body.get("orderName", "milk"))
    total_cost = req.params.get("totalCost", body.get("totalCost", 5))
    quantity   = req.params.get("quantity",   body.get("quantity", 1))

    try:
        total_cost = float(total_cost)
    except (TypeError, ValueError):
        total_cost = 5

    try:
        quantity = int(quantity)
    except (TypeError, ValueError):
        quantity = 1

    # Request an order
    order_payload = OrderPayload(
        order_name=order_name,
        total_cost=total_cost,
        quantity=quantity
    )

    instance_id = await client.start_new("process_orchestrator", client_input=order_payload)
    
    logging.info(f"Started orchestration with ID = '{instance_id}'.")

    response = client.create_check_status_response(req, instance_id)
    return response

@myApp.orchestration_trigger(context_name="context")
def process_orchestrator(context: df.DurableOrchestrationContext):   
    # Retry options for activity functions
    retry_interval_in_milliseconds = 2000
    max_number_of_attempts = 3
    retry_options = df.RetryOptions(retry_interval_in_milliseconds, max_number_of_attempts)
     
    # Reserve requested inventory 
    order_id = context.instance_id
    order_payload: OrderPayload = context.get_input()
    inventory_request = InventoryRequest(
        request_id=order_id, 
        item_name=order_payload.order_name,
        quantity=order_payload.quantity
    )
    
    inventory_result = yield context.call_activity_with_retry("reserve_inventory", retry_options, inventory_request)   
    
    # There's not enough inventory, so fail and notify the customer
    if not inventory_result['success']:
        notification = Notification(f"Insufficient inventory for {inventory_request.item_name}.")
        yield context.call_activity("notify_customer", notification)
        context.set_custom_status("Insufficient inventory.")
        return {'success': False} 
        
    # There is enough inventory, so process the payment 
    payment_request = PaymentRequest(
        request_id=order_id, 
        item_purchased=order_payload.order_name, 
        payment_amount=order_payload.total_cost, 
    )
    
    yield context.call_activity_with_retry("process_payment", retry_options, payment_request)
    
    try:
        # Update inventory
        yield context.call_activity_with_retry("update_inventory", retry_options, inventory_request)
    except Exception as e:
        logging.error(f"Error updating inventory: {e}")
        notification = Notification(f"Failed to process order for {inventory_request.item_name}. You're now getting a refund.")
        yield context.call_activity("notify_customer", notification)
        context.set_custom_status("Failed to update inventory.")
        return {'success': False}
    
    # Order placed successfully. Notify customer.
    notification = Notification(f"Order for {order_payload.order_name} placed successfully!")
    yield context.call_activity("notify_customer", notification)
    context.set_custom_status("Order placed successfully.")

    return {'success': True}

@myApp.activity_trigger(input_name="req")
def reserve_inventory(req: InventoryRequest):
    logging.info(f"Reserving inventory for order {req.request_id} of quantity {req.quantity} {req.item_name}.")

    if req.quantity > 10:
        logging.warning(f"Insufficient inventory for {req.item_name}. Requested: {req.quantity}")
        return {"success": False}
    
    sleep(5) # Dummy delay to simulate database call
    
    return {'success': True}

@myApp.activity_trigger(input_name="req")
def update_inventory(req: InventoryRequest):
    logging.info(f"Update inventory for {req.item_name}.")
    
    # In a real app, this would be a call to a database or external service to update inventory
    # For simplicity, we pretend the inventory has been updated and log the new quantity
    sleep(5) # Dummy delay to simulate database call
        
    logging.info(f"Inventory updated for {req.item_name}. Current quantity: 100.")
    
    # Activity functions must have a return value today
    return "Updated inventory."

@myApp.activity_trigger(input_name="notification")
def notify_customer(notification: Notification):
    logging.info(notification.message)
    
    # Simulate notification
    sleep(2) 
    
    # Activity functions must have a return value today
    return "Notified customer."

@myApp.activity_trigger(input_name="req")
def process_payment(req: PaymentRequest):
    logging.info(f"Processing payment for order {req.request_id} purchasing {req.item_purchased} with {req.payment_amount} {req.currency}.")
    
    # Simulate slow payment processing
    sleep(7) 

    logging.info(f"Payment request {req.request_id} processed successfully.")
    
    # Activity functions must have a return value today
    return "Processed payment."

